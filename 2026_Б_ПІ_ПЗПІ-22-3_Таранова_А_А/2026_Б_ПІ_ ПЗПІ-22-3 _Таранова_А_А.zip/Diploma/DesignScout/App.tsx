import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ActivityIndicator, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  useFonts,
  Manrope_400Regular,
  Manrope_600SemiBold,
  Manrope_700Bold,
} from '@expo-google-fonts/manrope';
import WelcomeScreen from './src/screens/WelcomeScreen';
import HomeScreen from './src/screens/HomeScreen';
import LessonsScreen from './src/screens/LessonsScreen';
import LessonDetailScreen from './src/screens/LessonDetailScreen';
import AnalysisScreen from './src/screens/AnalysisScreen';
import AnalysisResultScreen from './src/screens/AnalysisResultScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import QuizScreen from './src/screens/QuizScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import PracticeScreen from './src/screens/PracticeScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const COLORS = {
  primary: '#6D28D9',
  inactive: '#9CA3AF',
};
function CustomTabBar({ state, descriptors, navigation }: any) {
  const iconMap: Record<string, [string, string]> = {
    Home:     ['home',        'home-outline'],
    Courses:  ['book-open',   'book-open-outline'],
    Analysis: ['robot',       'robot-outline'],
    Profile:  ['account-circle', 'account-circle-outline'],
    Settings: ['cog',         'cog-outline'],
  };

  return (
    <View style={tabStyles.wrapper}>
      <View style={tabStyles.container}>
        {state.routes.map((route: any, index: number) => {
          const isFocused = state.index === index;
          const [activeIcon, inactiveIcon] = iconMap[route.name] ?? ['circle', 'circle-outline'];

          const onPress = () => {
            const event = navigation.emit({
              type: 'tabPress',
              target: route.key,
              canPreventDefault: true,
            });
            if (!isFocused && !event.defaultPrevented) {
              navigation.navigate(route.name);
            }
          };

          return (
            <TouchableOpacity
              key={route.key}
              onPress={onPress}
              style={tabStyles.tab}
              activeOpacity={0.7}
            >
              {isFocused ? (
                <View style={tabStyles.activeCircle}>
                  <MaterialCommunityIcons name={activeIcon as any} size={28} color="#FFF" />
                </View>
              ) : (
                <View style={tabStyles.inactiveContainer}>
                  <MaterialCommunityIcons name={inactiveIcon as any} size={28} color={COLORS.inactive} />
                </View>
              )}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator tabBar={(props) => <CustomTabBar {...props} />} screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Courses" component={LessonsScreen} />
      <Tab.Screen name="Analysis" component={AnalysisScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
      <Tab.Screen name="Settings" component={SettingsScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  let [fontsLoaded] = useFonts({
    Manrope_400Regular,
    Manrope_600SemiBold,
    Manrope_700Bold,
  });

  const [initialRoute, setInitialRoute] = useState<string | null>(null);

  useEffect(() => {
    const checkUser = async () => {
      try {
        const userData = await AsyncStorage.getItem('userData');
        setInitialRoute(userData ? 'Main' : 'Welcome');
      } catch (e) {
        setInitialRoute('Welcome');
      }
    };
    checkUser();
  }, []);

  if (!fontsLoaded || initialRoute === null) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#6D28D9" />
      </View>
    );
  }

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName={initialRoute} screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Welcome" component={WelcomeScreen} />
        <Stack.Screen name="Main" component={MainTabs} />
                <Stack.Screen
          name="LessonDetail"
          component={LessonDetailScreen}
          options={({ navigation }) => ({
            headerShown: true,
            title: 'Урок',
            headerStyle: { backgroundColor: '#6D28D9' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontFamily: 'Manrope_700Bold' },
            headerLeft: () => (
              <TouchableOpacity 
                onPress={() => navigation.goBack()}
                style={{ marginLeft: 16, marginRight: 16 }}
              >
                <MaterialCommunityIcons name="arrow-left" size={24} color="#FFF" />
              </TouchableOpacity>
            ),
          })}
        />

        <Stack.Screen
          name="Quiz"
          component={QuizScreen}
          options={{
            headerShown: true,
            title: 'Тест',
            headerStyle: { backgroundColor: '#6D28D9' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontFamily: 'Manrope_700Bold' },
            headerBackTitle: '',
            
          }}
        />
        <Stack.Screen
          name="AnalysisResult"
          component={AnalysisResultScreen}
          options={{
            headerShown: true,
            title: 'Результат аналізу',
            headerStyle: { backgroundColor: '#6D28D9' },
            headerTintColor: '#fff',
            headerTitleStyle: { fontFamily: 'Manrope_700Bold' },
            headerBackTitle: '',
          }}
        />
        <Stack.Screen 
          name="Practice" 
          component={PracticeScreen} 
          options={{ 
            headerShown: false, 
            presentation: 'modal' 
          }} 
        />
        <Stack.Screen
          name="Profile"
          component={ProfileScreen}
        />

      </Stack.Navigator>
    </NavigationContainer>
  );
}
const tabStyles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    bottom: 24,
    left: 20,
    right: 20,
  },
  container: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 45, 
    paddingVertical: 10,
    paddingHorizontal: 5,
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#6D28D9',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.15,
    shadowRadius: 20,
    elevation: 15, 
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeCircle: {
    width: 55,
    height: 55,
    borderRadius: 30,
    backgroundColor: '#6D28D9', 
    justifyContent: 'center',
    alignItems: 'center',
  },
  inactiveContainer: {
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
