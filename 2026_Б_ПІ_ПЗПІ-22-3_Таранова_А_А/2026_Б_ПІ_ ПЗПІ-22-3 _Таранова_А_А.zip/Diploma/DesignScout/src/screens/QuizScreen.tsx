import React, { useState, useMemo } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { COURSE_DATA } from '../data/courseData';

export default function QuizScreen({ route, navigation }: any) {
  const { moduleId } = route.params;

  const module = useMemo(() => {
    return COURSE_DATA.find(m => m.id === moduleId);
  }, [moduleId]);

  const questions = useMemo(() => {
    if (!module) return [];

    return module.lessons
      .map((lesson) => lesson.practiceTask)
      .filter(Boolean)
      .map((task) => {
        if (!task) return null;

        return {
          question: task.question,
          type: task.type,
          options:
            task.type === 'choice'
              ? task.options
              : task.type === 'boolean'
              ? ['Так', 'Ні']
              : [],
          correct:
            task.type === 'boolean'
              ? task.correctAnswer ? 0 : 1
              : task.correctAnswerIndex ?? 0,
          explanation: task.explanation,
        };
      })
      .filter(Boolean) as any[];
  }, [module]);

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(false);

  if (!module || questions.length === 0) {
    return (
      <View style={styles.container}>
        <Text style={styles.header}>Немає питань для цього модуля</Text>
      </View>
    );
  }

  const selectAnswer = (index: number) => {
    setAnswered(true);

    const isCorrect = index === questions[currentQuestion].correct;

    if (isCorrect) {
      setScore(prev => prev + 1);
    }

    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(prev => prev + 1);
        setAnswered(false);
      } else {
        const finalScore = score + (isCorrect ? 1 : 0);

        Alert.alert(
          'Результати',
          `Ти набрав ${finalScore}/${questions.length} балів!`,
          [
            {
              text: 'До профілю',
              onPress: () => navigation.navigate('Profile'),
            },
          ]
        );
      }
    }, 1200);
  };

  const q = questions[currentQuestion];

  return (
    <View style={styles.container}>
      <Text style={styles.header}>
        Модуль квіз: {module.title}
      </Text>

      <Text style={styles.question}>{q.question}</Text>

      <View style={styles.options}>
        {q.options.map((option: string, index: number) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.option,
              answered &&
                index === q.correct &&
                styles.correct,
              answered &&
                index !== q.correct &&
                styles.incorrect,
            ]}
            onPress={() => !answered && selectAnswer(index)}
            disabled={answered}
          >
            <Text style={styles.optionText}>{option}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.score}>
        {currentQuestion + 1}/{questions.length} • Очки: {score}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 20,
    justifyContent: 'center',
  },
  header: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  question: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 30,
  },
  options: {
    gap: 12,
  },
  option: {
    padding: 16,
    backgroundColor: 'white',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#eee',
  },
  correct: {
    backgroundColor: '#d4edda',
    borderColor: '#28a745',
  },
  incorrect: {
    backgroundColor: '#f9e7e9',
    borderColor: '#dc354600',
  },
  optionText: {
    textAlign: 'center',
    fontSize: 16,
  },
  score: {
    marginTop: 30,
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '600',
  },
});