import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons'; 

const COLORS = {
  primary: '#6D28D9',       
  background: '#F9FAFB',    
  textMain: '#1F2937',      
  textSecondary: '#6B7280', 
  cardBg: '#FFFFFF',        
  danger: '#EF4444',        
  successBg: '#D1FAE5',     
  successText: '#065F46',   
  accent: '#F59E0B',        
};

const defaultUserData = {
  lessonsCompleted: [],
  xp: 0,
  badges: [],
  streak: 0,
  name: 'Гість',
  level: 'Новачок',
  totalLessons: 24
};

const loadUserData = async () => {
  try {
    const jsonValue = await AsyncStorage.getItem('userData');
    if (jsonValue != null) {
      const parsedData = JSON.parse(jsonValue);
      // Зливаємо дефолтні дані з тими, що є в пам'яті, щоб нічого не зламалося
      return { ...defaultUserData, ...parsedData };
    }
    return defaultUserData;
  } catch (e) {
    console.error('❌ Помилка завантаження:', e);
    return defaultUserData;
  }
};

export default function ProfileScreen() {
  const navigation = useNavigation<any>();
  const [userData, setUserData] = useState(defaultUserData);
  const [loading, setLoading] = useState(true);

  // ВИКОРИСТОВУЄМО useFocusEffect ЗАМІСТЬ useEffect
  useFocusEffect(
    useCallback(() => {
      let isActive = true; // Для запобігання витоку пам'яті, якщо компонент розмонтується

      const fetchProfileData = async () => {
        setLoading(true);
        const data = await loadUserData();
        if (isActive) {
          setUserData(data);
          setLoading(false);
        }
      };

      fetchProfileData();

      return () => {
        isActive = false; // Очищення при відключенні фокусу
      };
    }, [])
  );

  const progressPercent = userData.totalLessons > 0
    ? (userData.lessonsCompleted.length / userData.totalLessons) * 100
    : 0;

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <Text style={styles.loadingText}>Завантаження профілю...</Text>
      </View>
    );
  }

  return (
    <View style={styles.fullContainer}>
      <ScrollView style={styles.container} contentContainerStyle={{ flexGrow: 1, paddingBottom: 100 }}>
        
        <View style={styles.header}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{userData.name.charAt(0)}</Text>
          </View>
          <Text style={styles.name}>{userData.name}</Text>
          <View style={styles.levelBadge}>
            <MaterialCommunityIcons name="star-circle" size={16} color="#FFD700" style={{ marginRight: 4 }} />
            <Text style={styles.level}>Рівень: {userData.level}</Text>
          </View>
        </View>

        <View style={styles.progressCard}>
          <View style={styles.cardHeader}>
            <MaterialCommunityIcons name="chart-box-outline" size={24} color={COLORS.primary} />
            <Text style={styles.progressTitle}>Прогрес навчання</Text>
          </View>
          
          <View style={styles.progressBarBg}>
            <View style={[styles.progressBarFill, { width: `${progressPercent}%` }]} />
          </View>
          <Text style={styles.progressText}>
            {userData.lessonsCompleted.length} з {userData.totalLessons} уроків {'\n'}
            <Text style={{ fontFamily: 'Manrope_700Bold', color: COLORS.primary }}>
              (+{userData.xp} XP)
            </Text>
          </Text>
        </View>

        <View style={styles.statsCard}>
          <View style={styles.statItem}>
            <MaterialCommunityIcons name="lightning-bolt" size={28} color="#F59E0B" />
            <Text style={styles.statNumber}>{userData.xp}</Text>
            <Text style={styles.statLabel}>Досвід</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.statItem}>
            <MaterialCommunityIcons name="fire" size={28} color="#EF4444" />
            <Text style={styles.statNumber}>{userData.streak}</Text>
            <Text style={styles.statLabel}>Стрік (дні)</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.statItem}>
            <MaterialCommunityIcons name="book-open-variant" size={28} color={COLORS.primary} />
            <Text style={styles.statNumber}>{userData.lessonsCompleted.length}</Text>
            <Text style={styles.statLabel}>Уроків</Text>
          </View>
        </View>

        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionIconContainer}>
              <MaterialCommunityIcons name="trophy-outline" size={24} color={COLORS.textMain} />
            </View>
            <Text style={styles.sectionTitle}>Досягнення ({userData.badges.length})</Text>
          </View>
          
          {userData.badges.length > 0 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.badgesList}>
              {userData.badges.map((badge, index) => (
                <View key={index} style={styles.badge}>
                  <Text style={styles.badgeText}>{badge}</Text>
                </View>
              ))}
            </ScrollView>
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.noDataText}>Заверши повністю перший модуль, щоб отримати нагороду!</Text>
            </View>
          )}
        </View>

        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionIconContainer}>
              <MaterialCommunityIcons name="check-decagram-outline" size={24} color={COLORS.textMain} />
            </View>
            <Text style={styles.sectionTitle}>Завершені уроки</Text>
          </View>

          {userData.lessonsCompleted.length > 0 ? (
            userData.lessonsCompleted.map((lessonId, index) => (
              <View key={index} style={styles.lessonCompleted}>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <MaterialCommunityIcons name="file-document-check-outline" size={20} color={COLORS.successText} style={{ marginRight: 10 }} />
                    <Text style={styles.lessonCompletedText}>Урок {lessonId}</Text>
                </View>
                <MaterialCommunityIcons name="check-circle" size={20} color={COLORS.successText} />
              </View>
            ))
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.noDataText}>Ти ще не завершив жодного уроку</Text>
            </View>
          )}
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  fullContainer: { flex: 1, backgroundColor: COLORS.background },
  container: { flex: 1 },
  center: { justifyContent: 'center', alignItems: 'center' },
  loadingText: { fontSize: 16, color: COLORS.textSecondary, fontFamily: 'Manrope_600SemiBold' },

  header: {
    backgroundColor: COLORS.primary,
    paddingTop: 50,
    paddingBottom: 40,
    alignItems: 'center',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 10,
  },
  avatar: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: 'rgba(255,255,255,0.2)',
    marginBottom: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.4)',
  },
  avatarText: {
    fontSize: 40,
    color: '#FFF',
    fontFamily: 'Manrope_700Bold',
  },
  name: {
    fontSize: 26,
    color: '#FFF',
    fontFamily: 'Manrope_700Bold',
    marginBottom: 6,
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  level: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.9)',
    fontFamily: 'Manrope_600SemiBold',
  },

  progressCard: {
    backgroundColor: COLORS.cardBg,
    marginHorizontal: 20,
    marginTop: -25,
    padding: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 5,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressTitle: {
    fontSize: 18,
    color: COLORS.textMain,
    fontFamily: 'Manrope_700Bold',
    marginLeft: 10,
  },
  progressBarBg: {
    height: 10,
    backgroundColor: '#E5E7EB',
    borderRadius: 5,
    overflow: 'hidden',
    marginBottom: 10,
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: COLORS.primary,
    borderRadius: 5,
  },
  progressText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    textAlign: 'center',
    fontFamily: 'Manrope_400Regular',
    lineHeight: 20,
  },

  statsCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: COLORS.cardBg,
    marginHorizontal: 20,
    marginTop: 20,
    padding: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  statItem: { alignItems: 'center', flex: 1, justifyContent: 'center' },
  divider: { width: 1, height: '80%', backgroundColor: '#E5E7EB' },
  statNumber: {
    fontSize: 20,
    color: COLORS.textMain,
    fontFamily: 'Manrope_700Bold',
    marginTop: 4,
  },
  statLabel: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontFamily: 'Manrope_600SemiBold',
  },

  sectionContainer: {
    marginTop: 24,
    paddingHorizontal: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionIconContainer: {
    width: 32, 
    alignItems: 'flex-start',
  },
  sectionTitle: {
    fontSize: 18,
    color: COLORS.textMain,
    fontFamily: 'Manrope_700Bold',
  },
  badgesList: {
    paddingRight: 20,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F3E8FF',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
    marginRight: 10,
    borderWidth: 1,
    borderColor: '#D8B4FE',
  },
  badgeText: {
    fontSize: 14,
    color: COLORS.primary,
    fontFamily: 'Manrope_600SemiBold',
  },
  emptyState: {
    paddingTop: 4,
    paddingBottom: 10,
  },
  noDataText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontFamily: 'Manrope_400Regular',
    fontStyle: 'italic',
  },

  lessonCompleted: {
    backgroundColor: COLORS.successBg,
    padding: 16,
    borderRadius: 12,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  lessonCompletedText: {
    fontSize: 16,
    color: COLORS.successText,
    fontFamily: 'Manrope_600SemiBold',
  },
});
