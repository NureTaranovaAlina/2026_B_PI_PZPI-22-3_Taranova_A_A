import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function WelcomeScreen({ navigation }: any) {
    const [name, setName] = useState('');

    const handleStart = async () => {
    if (name.trim().length === 0) {
        Alert.alert('Упс!', 'Будь ласка, введи своє ім’я.');
        return;
    }

    try {
        const today = new Date().toDateString();
        const initialData = {
        lessonsCompleted: [],
        xp: 0,
        badges: [],
        streak: 1,
        lastLessonDate: today,
        name: name.trim(), 
        level: 'Новачок',
        totalLessons: 24
        };

        await AsyncStorage.setItem('userData', JSON.stringify(initialData));
        
        navigation.reset({
        index: 0,
        routes: [{ name: 'Main' }],
        });
    } catch (e) {
        console.error(e);
    }
    };

    return (
    <View style={styles.container}>
        <View style={styles.content}>
        <Text style={styles.emoji}>🎨</Text>
        <Text style={styles.title}>Вітаємо в DesignScout!</Text>
        <Text style={styles.subtitle}>Твій персональний ментор з UX/UI дизайну.</Text>
        
        <View style={styles.inputContainer}>
            <Text style={styles.label}>Як до тебе звертатися?</Text>
            <TextInput
            style={styles.input}
            placeholder="Твоє ім'я"
            value={name}
            onChangeText={setName}
            autoCorrect={false}
            />
        </View>

        <TouchableOpacity style={styles.button} onPress={handleStart}>
            <Text style={styles.buttonText}>Почати навчання 🚀</Text>
        </TouchableOpacity>
        </View>
    </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#fff', justifyContent: 'center', padding: 20 },
    content: { alignItems: 'center', width: '100%' },
    emoji: { fontSize: 60, marginBottom: 20 },
    title: { fontSize: 28, fontWeight: 'bold', marginBottom: 10, textAlign: 'center', color: '#333' },
    subtitle: { fontSize: 16, color: '#666', textAlign: 'center', marginBottom: 40 },
    inputContainer: { width: '100%', marginBottom: 30 },
    label: { fontSize: 14, color: '#333', marginBottom: 8, fontWeight: '600' },
    input: { 
    width: '100%', 
    height: 50, 
    borderWidth: 1, 
    borderColor: '#ddd', 
    borderRadius: 12, 
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#f9f9f9'
    },
    button: {
    backgroundColor: '#6200ee',
    width: '100%',
    height: 55,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#6200ee',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
    },
    buttonText: { color: 'white', fontSize: 18, fontWeight: 'bold' }
});
