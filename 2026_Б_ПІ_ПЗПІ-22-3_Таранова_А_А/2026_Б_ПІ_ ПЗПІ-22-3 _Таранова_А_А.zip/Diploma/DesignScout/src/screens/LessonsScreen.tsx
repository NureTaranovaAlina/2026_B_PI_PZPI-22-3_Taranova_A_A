import React, { useState } from 'react';
import { View, Text, SectionList, TouchableOpacity, StyleSheet, LayoutAnimation, Platform, UIManager, SafeAreaView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COURSE_DATA, Module, Lesson } from '../data/courseData';
import { useFocusEffect } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const COLORS = {
  primary: '#6D28D9',       
  background: '#F9FAFB',    
  cardBg: '#FFFFFF',        
  textMain: '#1F2937',      
  textSecondary: '#6B7280', 
  success: '#10B981',       
  successLight: '#D1FAE5',
  border: '#E5E7EB',
  lockedBg: '#F3F4F6',      
  lockedText: '#9CA3AF',    
};

export default function LessonsScreen({ navigation }: any) {
  const [expandedModule, setExpandedModule] = useState<string | null>(null);
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);

  useFocusEffect(
    React.useCallback(() => {
      loadProgress();
    }, [])
  );

  const loadProgress = async () => {
    try {
      const data = await AsyncStorage.getItem('userData');
      if (data) {
        const parsed = JSON.parse(data);
        setCompletedLessons(parsed.lessonsCompleted || []);
      }
    } catch (e) {
      console.error('Помилка завантаження прогресу', e);
    }
  };

  const toggleModule = (moduleId: string, isLocked: boolean) => {
    if (isLocked) return; 
    
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpandedModule(expandedModule === moduleId ? null : moduleId);
  };

  const navigateToLesson = (lesson: Lesson, moduleTitle: string) => {
    navigation.navigate('LessonDetail', {
      lesson: { ...lesson, moduleTitle }
    });
  };

  const startModuleQuiz = (module: Module) => {
    navigation.navigate('Quiz', { 
        moduleId: module.id,
        moduleTitle: module.title 
    });
  };

  const isModuleCompleted = (moduleIndex: number) => {
    if (moduleIndex < 0) return true; 
    const module = COURSE_DATA[moduleIndex];
    const completedCount = module.lessons.filter(l => completedLessons.includes(l.id)).length;
    return completedCount === module.lessons.length;
  };

  const sections = COURSE_DATA.map((module) => ({
    ...module,
    data: expandedModule === module.id ? [...module.lessons, { id: `quiz-${module.id}`, isQuizButton: true, module }] : [],
  }));

  const renderHeader = ({ section }: { section: Module }) => {

    const moduleIndex = COURSE_DATA.findIndex(m => m.id === section.id);
    
    const isLocked = !isModuleCompleted(moduleIndex - 1);

    const moduleCompletedCount = section.lessons.filter(l => completedLessons.includes(l.id)).length;
    const totalCount = section.lessons.length;
    const isModuleFinished = moduleCompletedCount === totalCount;
    const isExpanded = expandedModule === section.id;

    return (
      <TouchableOpacity 
        style={[
          styles.moduleHeader, 
          isExpanded && styles.moduleHeaderExpanded,
          isLocked && styles.moduleHeaderLocked 
        ]} 
        onPress={() => toggleModule(section.id, isLocked)}
        activeOpacity={isLocked ? 1 : 0.8} 
      >
        <View style={styles.moduleHeaderContent}>
          <View style={styles.moduleInfo}>
            <Text style={[styles.moduleTitle, isLocked && styles.lockedText]}>
              {section.title}
            </Text>
            <Text style={[styles.moduleDesc, isLocked && styles.lockedText]} numberOfLines={1}>
              {section.description}
            </Text>
          </View>
          <View style={styles.rightSide}>
            
            {isLocked ? (
              <View style={styles.lockedBadge}>
                <MaterialCommunityIcons name="lock" size={20} color={COLORS.lockedText} />
              </View>
            ) : (
              <>
                <View style={[styles.progressBadge, isModuleFinished && styles.progressBadgeComplete]}>
                  <Text style={[styles.progressText, isModuleFinished && styles.progressTextComplete]}>
                    {moduleCompletedCount}/{totalCount}
                  </Text>
                </View>
                <MaterialCommunityIcons 
                  name={isExpanded ? 'chevron-up' : 'chevron-down'} 
                  size={24} 
                  color={COLORS.textSecondary} 
                />
              </>
            )}
            
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const renderItem = ({ item, section, index }: { item: any, section: Module, index: number }) => {
    if (item.isQuizButton) {
        const moduleCompletedCount = section.lessons.filter(l => completedLessons.includes(l.id)).length;
        const totalCount = section.lessons.length;
        const isModuleFinished = moduleCompletedCount === totalCount;

        if (!isModuleFinished) return null; 

        return (
            <TouchableOpacity 
                style={styles.quizButton}
                onPress={() => startModuleQuiz(item.module)}
                activeOpacity={0.9}
            >
                <MaterialCommunityIcons name="brain" size={20} color="#FFF" style={{ marginRight: 8 }} />
                <Text style={styles.quizButtonText}>Пройти тест модуля</Text>
            </TouchableOpacity>
        );
    }

    const isCompleted = completedLessons.includes(item.id);
    const moduleCompletedCount = section.lessons.filter(l => completedLessons.includes(l.id)).length;
    const isModuleFinished = moduleCompletedCount === section.lessons.length;
    const isLastItem = !isModuleFinished && index === section.lessons.length - 1;

    return (
      <TouchableOpacity 
        style={[
          styles.lessonItem, 
          isCompleted && styles.lessonItemCompleted,
          isLastItem && styles.lessonItemLast
        ]}
        onPress={() => navigateToLesson(item, section.title)}
        activeOpacity={0.7}
      >
        <View style={styles.iconContainer}>
            {isCompleted ? (
                <MaterialCommunityIcons name="check-circle" size={26} color={COLORS.success} />
            ) : (
                <MaterialCommunityIcons name="circle-outline" size={26} color={COLORS.border} />
            )}
        </View>
        
        <View style={styles.lessonTextContainer}>
          <Text style={[styles.lessonTitle, isCompleted && styles.completedText]}>
            {item.title}
          </Text>
          <View style={styles.durationContainer}>
            <MaterialCommunityIcons name="clock-outline" size={14} color={COLORS.textSecondary} />
            <Text style={styles.lessonDuration}>{item.duration}</Text>
          </View>
        </View>
        
        <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.border} />
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Курси</Text>
      </View>
      <SectionList
        sections={sections}
        keyExtractor={(item) => item.id}
        renderSectionHeader={renderHeader}
        renderItem={renderItem}
        contentContainerStyle={styles.listContent}
        stickySectionHeadersEnabled={false}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  
  header: {
    paddingTop: 20, 
    paddingHorizontal: 20,
    paddingBottom: 16,
    backgroundColor: COLORS.background,
  },
  headerTitle: {
    fontSize: 28,
    color: COLORS.textMain,
    fontFamily: 'Manrope_700Bold',
  },

  listContent: { paddingHorizontal: 16, paddingBottom: 100 }, 
  
  moduleHeader: {
    backgroundColor: COLORS.cardBg,
    padding: 20,
    borderRadius: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 4,
    zIndex: 1,
    borderWidth: 1,
    borderColor: '#F3F4F6',
  },
  moduleHeaderExpanded: {
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    marginBottom: 0,
    borderBottomWidth: 0,
  },

  moduleHeaderLocked: {
    backgroundColor: COLORS.lockedBg,
    borderColor: '#E5E7EB',
    shadowOpacity: 0,
    elevation: 0,
  },
  lockedText: {
    color: COLORS.lockedText,
  },
  lockedBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#E5E7EB',
    justifyContent: 'center',
    alignItems: 'center',
  },

  moduleHeaderContent: {
      flex: 1,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center'
  },
  moduleInfo: { flex: 1, marginRight: 16 },
  moduleTitle: { 
    fontSize: 18, 
    fontFamily: 'Manrope_700Bold', 
    color: COLORS.textMain, 
    marginBottom: 4 
  },
  moduleDesc: { 
    fontSize: 13, 
    fontFamily: 'Manrope_400Regular',
    color: COLORS.textSecondary 
  },
  rightSide: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  
  progressBadge: {
      backgroundColor: '#F3E8FF',
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 12,
  },
  progressBadgeComplete: { backgroundColor: COLORS.successLight },
  progressText: { 
    fontSize: 13, 
    fontFamily: 'Manrope_700Bold', 
    color: COLORS.primary 
  },
  progressTextComplete: { color: COLORS.success },

  lessonItem: {
    backgroundColor: COLORS.cardBg,
    padding: 16,
    paddingVertical: 18,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  lessonItemLast: {
      borderBottomLeftRadius: 16,
      borderBottomRightRadius: 16,
      borderBottomWidth: 0,
      marginBottom: 12,
      shadowColor: COLORS.primary,
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.05,
      shadowRadius: 10,
      elevation: 3,
  },
  lessonItemCompleted: { backgroundColor: '#FAFAFA' },
  iconContainer: { marginRight: 14 },
  
  lessonTextContainer: { flex: 1 },
  lessonTitle: { 
    fontSize: 15, 
    fontFamily: 'Manrope_600SemiBold',
    color: COLORS.textMain,
    marginBottom: 4
  },
  completedText: { 
    color: '#9CA3AF', 
  },
  durationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  lessonDuration: { 
    fontSize: 13, 
    fontFamily: 'Manrope_400Regular',
    color: COLORS.textSecondary 
  },

  quizButton: {
      backgroundColor: COLORS.primary,
      padding: 18,
      borderBottomLeftRadius: 16,
      borderBottomRightRadius: 16,
      alignItems: 'center',
      flexDirection: 'row',
      justifyContent: 'center',
      marginBottom: 12,
  },
  quizButtonText: {
      color: 'white',
      fontSize: 16,
      fontFamily: 'Manrope_700Bold',
  }
});
