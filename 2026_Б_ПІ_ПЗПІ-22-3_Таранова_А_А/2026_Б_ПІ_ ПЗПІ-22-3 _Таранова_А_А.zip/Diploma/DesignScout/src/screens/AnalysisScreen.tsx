import React, { useState } from 'react';
import { View, Text, Image, StyleSheet, Alert, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useNavigation } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const COLORS = {
  primary: '#6D28D9',
  primaryLight: '#8B5CF6',
  background: '#F9FAFB',
  textMain: '#1F2937',
  textSecondary: '#6B7280',
  cardBg: '#FFFFFF',
  success: '#10B981',
};

export default function AnalysisScreen() {
  const navigation = useNavigation<any>();
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Помилка', 'Потрібен доступ до галереї');
      return;
    }

    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: false,
      quality: 0.8,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      setImage(result.assets[0].uri);
    }
  };

  const analyzeDesign = async () => {
    if (!image) {
      Alert.alert('Помилка', 'Спочатку вибери зображення');
      return;
    }
    
    setIsAnalyzing(true);

    try {
      const formData = new FormData();
      formData.append('file', {
        uri: image,
        type: 'image/jpeg',
        name: 'design.jpg',
      } as any);

      const response = await fetch('http://192.168.110.54:8000/analyze', {
        method: 'POST',
        body: formData,
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success) {
        navigation.navigate('AnalysisResult', { 
          result, 
          imageUri: image 
        });
      } else {
        Alert.alert('Помилка', 'Сервер повернув помилку');
      }
      
    } catch (error) {
      console.error('Помилка аналізу:', error);
      Alert.alert(
        'Помилка з\'єднання', 
        'Перевірити:\n1. Запущений сервер (порт 8000)\n2. Правильний IP\n3. Мережа та той самий WiFi'
      );
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      
      <View style={styles.headerContainer}>
        <MaterialCommunityIcons name="robot-outline" size={40} color={COLORS.primary} style={styles.headerIcon} />
        <Text style={styles.title}>ШІ-Аналіз Макету</Text>
        <Text style={styles.subtitle}>
          Завантаж скріншот свого дизайну, і наш штучний інтелект знайде помилки та дасть поради щодо покращення.
        </Text>
      </View>
      
      <TouchableOpacity 
        style={[styles.uploadBox, image && styles.uploadBoxWithImage]} 
        onPress={pickImage}
        activeOpacity={0.8}
      >
        {image ? (
          <Image source={{ uri: image }} style={styles.imagePreview} />
        ) : (
          <View style={styles.placeholder}>
            <View style={styles.iconCircle}>
              <MaterialCommunityIcons name="image-plus" size={32} color={COLORS.primary} />
            </View>
            <Text style={styles.uploadTitle}>Натисни, щоб обрати</Text>
            <Text style={styles.uploadSubtitle}>Підтримуються JPG, PNG</Text>
          </View>
        )}
        
        {image && (
          <View style={styles.changeImageBadge}>
            <MaterialCommunityIcons name="pencil" size={16} color="#FFF" />
          </View>
        )}
      </TouchableOpacity>

      {image && (
        <View style={styles.actionContainer}>
          <TouchableOpacity 
            style={[styles.analyzeButton, isAnalyzing && styles.analyzeButtonDisabled]} 
            onPress={analyzeDesign}
            disabled={isAnalyzing}
          >
            {isAnalyzing ? (
              <ActivityIndicator color="#FFF" size="small" style={{ marginRight: 10 }} />
            ) : (
              <MaterialCommunityIcons name="auto-fix" size={20} color="#FFF" style={{ marginRight: 8 }} />
            )}
            <Text style={styles.analyzeButtonText}>
              {isAnalyzing ? "Аналізуємо макет..." : "Запустити аналіз"}
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { 
    flexGrow: 1, 
    padding: 24, 
    paddingTop: 60, 
    backgroundColor: COLORS.background,
    paddingBottom: 100, 
  },
  
  headerContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  headerIcon: {
    marginBottom: 12,
  },
  title: {
    fontSize: 24,
    color: COLORS.textMain,
    fontFamily: 'Manrope_700Bold',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontFamily: 'Manrope_400Regular',
    textAlign: 'center',
    lineHeight: 20,
    paddingHorizontal: 10,
  },
  uploadBox: {
    width: '100%',
    height: 400,
    backgroundColor: COLORS.cardBg,
    borderRadius: 24,
    borderWidth: 2,
    borderColor: '#E5E7EB',
    borderStyle: 'dashed', 
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
    overflow: 'hidden', 
  },
  uploadBoxWithImage: {
    borderStyle: 'solid',
    borderColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  placeholder: {
    alignItems: 'center',
    padding: 20,
  },
  iconCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#F3E8FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  uploadTitle: {
    fontSize: 16,
    color: COLORS.textMain,
    fontFamily: 'Manrope_600SemiBold',
    marginBottom: 4,
  },
  uploadSubtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontFamily: 'Manrope_400Regular',
  },
  imagePreview: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
    backgroundColor: '#000', 
  },
  changeImageBadge: {
    position: 'absolute',
    bottom: 16,
    right: 16,
    backgroundColor: 'rgba(0,0,0,0.6)',
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },

  actionContainer: {
    width: '100%',
  },
  analyzeButton: {
    flexDirection: 'row',
    backgroundColor: COLORS.success, 
    paddingVertical: 16,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: COLORS.success,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  analyzeButtonDisabled: {
    backgroundColor: '#9CA3AF',
    shadowOpacity: 0,
    elevation: 0,
  },
  analyzeButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontFamily: 'Manrope_700Bold',
  },
  infoBox: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 24,
  },
  infoText: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontFamily: 'Manrope_400Regular',
    marginLeft: 6,
  },
});

