import React from 'react';
import { View, Text, Image, ScrollView, StyleSheet } from 'react-native';

interface AnalysisResult {
  success: boolean;
  image_width: number;
  image_height: number;
  issues: Array<{
    type: string;
    severity: 'low' | 'medium' | 'high';
    message: string;
    x: number;
    y: number;
    width: number;
    height: number;
  }>;
  score?: number;
}

export default function AnalysisResultScreen({ route }: any) {
  const { result, imageUri } = route.params;

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Результат ШІ-аналізу</Text>
      
      <View style={styles.scoreContainer}>
        <Text style={styles.score}>
          {result.score ? `${result.score}%` : 'N/A'}
        </Text>
        <Text style={styles.scoreLabel}>Оцінка дизайну</Text>
      </View>

      <Image source={{ uri: imageUri }} style={styles.image} />

      <View style={styles.issuesContainer}>
        <Text style={styles.issuesHeader}>
          Виявлені проблеми ({result.issues?.length || 0}):
        </Text>
        
        {result.issues && result.issues.length > 0 ? (
          result.issues.map((issue: any, index: number) => (
            <View 
              key={index} 
              style={[
                styles.issueCard, 
                issue.severity === 'high' ? styles.severityHigh : 
                issue.severity === 'medium' ? styles.severityMedium : styles.severityLow
              ]}
            >
              <Text style={styles.issueType}>{issue.type.toUpperCase()}</Text>
              <Text style={styles.issueMessage}>{issue.message}</Text>
            </View>
          ))
        ) : (
          <Text style={styles.noIssues}>✅ Дизайн без критичних помилок!</Text>
        )}
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>
          Аналіз виконано ШІ-моделлю DesignScout
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#f5f5f5', 
    padding: 20 
  },
  header: { 
    fontSize: 24, 
    fontWeight: 'bold', 
    textAlign: 'center', 
    marginBottom: 24,
    marginTop: 10
  },
  scoreContainer: {
    backgroundColor: 'white',
    padding: 24,
    borderRadius: 16,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  score: { 
    fontSize: 48, 
    fontWeight: 'bold', 
    color: '#28a745' 
  },
  scoreLabel: { 
    fontSize: 16, 
    color: '#666', 
    marginTop: 4 
  },
  image: { 
    width: 320, 
    height: 240, 
    borderRadius: 12, 
    marginBottom: 20,
    alignSelf: 'center'
  },
  issuesContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  issuesHeader: { 
    fontSize: 18, 
    fontWeight: '600', 
    marginBottom: 16,
    color: '#333'
  },
  issueCard: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    borderLeftWidth: 4,
  },
  severityHigh: {
    backgroundColor: '#fdf2f2',
    borderLeftColor: '#dc3545',
  },
  severityMedium: {
    backgroundColor: '#fff3cd',
    borderLeftColor: '#ffc107',
  },
  severityLow: {
    backgroundColor: '#d1ecf1',
    borderLeftColor: '#17a2b8',
  },
  issueType: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  issueMessage: {
    fontSize: 15,
    color: '#555',
    lineHeight: 22,
  },
  noIssues: {
    fontSize: 16,
    color: '#28a745',
    textAlign: 'center',
    padding: 20,
    fontWeight: '600',
  },
  footer: {
    alignItems: 'center',
    marginTop: 20,
  },
  footerText: {
    fontSize: 12,
    color: '#999',
    fontStyle: 'italic',
  }
});
