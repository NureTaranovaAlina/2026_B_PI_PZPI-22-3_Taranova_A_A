import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons'; 


const COLORS = {
  primary: '#6D28D9',     
  background: '#F9FAFB',  
  textMain: '#111827',    
  textSecondary: '#6B7280', 
  cardBg: '#FFFFFF',      
  accentTeal: '#06B6D4',  
  accentGreen: '#22C55E', 
  accentRed: '#EF4444',   
};

export default function HomeScreen({ navigation }: any) {
  
  const MenuCard = ({ title, subtitle, icon, color, onPress }: any) => (
    <TouchableOpacity 
      style={styles.card} 
      onPress={onPress}
      activeOpacity={0.8}
    >
      <View style={[styles.iconBox, { backgroundColor: color + '20' }]}> 
        <MaterialCommunityIcons name={icon} size={32} color={color} />
      </View>
      <View style={styles.cardContent}>
        <Text style={styles.cardTitle}>{title}</Text>
        <Text style={styles.cardSubtitle}>{subtitle}</Text>
      </View>
      <MaterialCommunityIcons name="chevron-right" size={24} color="#D1D5DB" />
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Привіт, дизайнере! 👋</Text>
            <Text style={styles.subGreeting}>Що будемо вчити сьогодні?</Text>
          </View>
          <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>A</Text>
            </View>
          </TouchableOpacity>
        </View>

        <Text style={styles.sectionTitle}>Меню</Text>

        <View style={styles.cardsContainer}>
          <MenuCard 
            title="Навчання" 
            subtitle="Модулі, уроки та практика"
            icon="book-open-variant"
            color={COLORS.primary}
            onPress={() => navigation.navigate('Courses')}
          />

          <MenuCard 
            title="ШІ Аналіз" 
            subtitle="Завантаж макет для перевірки"
            icon="robot"
            color={COLORS.accentTeal}
            onPress={() => navigation.navigate('Analysis')}
          />

          <MenuCard 
            title="Мій Профіль" 
            subtitle="Досягнення та статистика"
            icon="account-circle"
            color={COLORS.accentGreen}
            onPress={() => navigation.navigate('Profile')}
          />
        </View>

        <View style={styles.tipBanner}>
            <MaterialCommunityIcons name="lightbulb-on-outline" size={24} color="#FFF" />
            <View style={styles.tipContent}>
                <Text style={styles.tipTitle}>Порада дня</Text>
                <Text style={styles.tipText}>Завжди перевіряй контраст тексту (min 4.5:1).</Text>
            </View>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  scrollContent: { padding: 20 },
  
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 30,
    marginTop: 10,
  },
  greeting: { 
    fontSize: 24, 
    fontWeight: 'bold', 
    color: COLORS.textMain, 
    fontFamily: 'Manrope_700Bold',
  },
  subGreeting: { 
    fontSize: 16, 
    color: COLORS.textSecondary, 
    marginTop: 4, 
    fontFamily: 'Manrope_400Regular',
  },
  
  avatar: {
    width: 48, height: 48,
    borderRadius: 24,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: COLORS.primary,
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 4,
  },
  avatarText: { 
    color: '#FFF', 
    fontSize: 20, 
    fontWeight: 'bold',
  fontFamily: 'Manrope_700Bold',
  },

  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: COLORS.textMain,
    marginBottom: 16,
    fontFamily: 'Manrope_700Bold',
  },

  cardsContainer: { gap: 16 },

  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.cardBg,
    padding: 16,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 10,
    elevation: 2,
  },
  iconBox: {
    width: 56, height: 56,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  cardContent: { flex: 1 },
  cardTitle: { 
    fontSize: 18, 
    fontWeight: '600', 
    color: COLORS.textMain, 
    marginBottom: 4, 
    fontFamily: 'Manrope_600SemiBold',

  },
  cardSubtitle: { 
    fontSize: 14, 
    color: COLORS.textSecondary, 
    fontFamily: 'Manrope_400Regular',
  },

  tipBanner: {
      marginTop: 30,
      backgroundColor: COLORS.textMain, 
      borderRadius: 16,
      padding: 20,
      flexDirection: 'row',
      alignItems: 'center',
  },
  tipContent: { marginLeft: 16, flex: 1 },
  tipTitle: { 
    color: '#FFF', 
    fontWeight: 'bold', 
    fontSize: 16, 
    marginBottom: 4, 
    fontFamily: 'Manrope_600SemiBold',  
  },
  tipText: { 
    color: '#D1D5DB', 
    fontSize: 14, 
    fontFamily: 'Manrope_400Regular', 
  },
});
