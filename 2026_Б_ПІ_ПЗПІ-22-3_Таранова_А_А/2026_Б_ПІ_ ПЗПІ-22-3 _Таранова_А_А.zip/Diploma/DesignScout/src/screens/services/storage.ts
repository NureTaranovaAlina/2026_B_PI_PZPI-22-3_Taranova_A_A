import AsyncStorage from '@react-native-async-storage/async-storage';

interface UserData {
  lessonsCompleted: string[];  // ['1', '2', '3']
  xp: number;                 // 0, 50, 150...
  badges: string[];           // ['Урок 1', 'Колірний гуру']
  streak: number;             // днів поспіль
  name: string;               // 'Аліна Таранова'
  level: string;              // 'Новачок', 'Середній'
  totalLessons: number;       // 15
}

export const saveUserData = async (data: UserData): Promise<void> => {
  try {
    await AsyncStorage.setItem('userData', JSON.stringify(data));
    console.log('💾 Збережено:', data);
  } catch (e) {
    console.error('❌ Помилка збереження:', e);
  }
};

export const loadUserData = async (): Promise<UserData> => {
  try {
    const jsonValue = await AsyncStorage.getItem('userData');
    const data: UserData = jsonValue != null ? JSON.parse(jsonValue) : {
      lessonsCompleted: [],
      xp: 0,
      badges: [],
      streak: 0,
      name: 'Аліна Таранова',
      level: 'Новачок',
      totalLessons: 15
    };
    console.log('📂 Завантажено:', data);
    return data;
  } catch (e) {
    console.error('❌ Помилка завантаження:', e);
    return {
      lessonsCompleted: [],
      xp: 0,
      badges: [],
      streak: 0,
      name: 'Аліна Таранова',
      level: 'Новачок',
      totalLessons: 15
    };
  }
};

export const completeLesson = async (lessonId: string): Promise<UserData> => {
  try {
    const data = await loadUserData();
    
    // Перевіряємо, чи урок ще не завершений
    if (!data.lessonsCompleted.includes(lessonId)) {
      data.lessonsCompleted.push(lessonId);
      data.xp += 50;
      data.streak += 1;
      
      // Новий бейдж
      const badgeName = lessonId === '1' ? 'UX Новачок' : 
                       lessonId === '2' ? 'Колірний гуру' : 
                       `Експерт ${lessonId}`;
      data.badges.push(badgeName);
      
      // Оновлюємо рівень
      if (data.xp >= 200) data.level = 'Середній';
      if (data.xp >= 500) data.level = 'Просунутий';
      
      await saveUserData(data);
      console.log('🎉 Урок завершено:', lessonId, 'XP:', data.xp);
    }
    
    return data;
  } catch (e) {
    console.error('❌ Помилка завершення уроку:', e);
    return await loadUserData();
  }
};

export const resetProgress = async (): Promise<void> => {
  try {
    await AsyncStorage.removeItem('userData');
    console.log('🗑️ Прогрес скинуто');
  } catch (e) {
    console.error('❌ Помилка скидання:', e);
  }
};

