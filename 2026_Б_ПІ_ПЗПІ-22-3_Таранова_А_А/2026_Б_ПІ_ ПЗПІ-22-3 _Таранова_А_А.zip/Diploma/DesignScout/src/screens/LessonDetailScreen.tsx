import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Modal } from 'react-native';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COURSE_DATA, Lesson, Module } from '../data/courseData'; 

const COLORS = {
  primary: '#6D28D9',       
  background: '#F9FAFB',    
  cardBg: '#FFFFFF',        
  textMain: '#1F2937',      
  textSecondary: '#6B7280', 
  success: '#10B981',       
  accent: '#F59E0B',        
  practiceBg: '#EEF2FF',    
  overlay: 'rgba(0, 0, 0, 0.5)',
  disabledBg: '#E5E7EB',    
  disabledText: '#9CA3AF',  
};

const completeLesson = async (lessonId: string, currentModule: Module) => {
  try {
    const existingData = await AsyncStorage.getItem('userData');
    const data = existingData ? JSON.parse(existingData) : {
      lessonsCompleted: [],
      xp: 0,
      badges: [],
      streak: 1, 
      lastLessonDate: new Date().toDateString(), 
      name: 'Гість',
      level: 'Новачок',
      totalLessons: 24 
    };
    
    let newBadgeEarned = null; 

    if (!data.lessonsCompleted.includes(lessonId)) {
      data.lessonsCompleted.push(lessonId);
      data.xp += 50;
      
      const today = new Date().toDateString(); 
      if (data.lastLessonDate !== today) {
        data.streak += 1;          
        data.lastLessonDate = today; 
      }

      const isModuleCompleted = currentModule.lessons.every(
        (l) => data.lessonsCompleted.includes(l.id)
      );

      const badgeName = `🏆 ${currentModule.title.split('.')[0]}`; 
      
      if (isModuleCompleted && !data.badges.includes(badgeName)) {
        data.badges.push(badgeName);
        data.xp += 100; 
        newBadgeEarned = badgeName;
      }
      
      await AsyncStorage.setItem('userData', JSON.stringify(data));
    }
    
    return { data, newBadgeEarned };
  } catch (error) {
    console.error('❌ Помилка:', error);
    return null; 
  }
};

export default function LessonDetailScreen({ route }: any) {
  const navigation = useNavigation<any>();
  const { lesson } = route.params; 

  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [sessionStats, setSessionStats] = useState({ xp: 0, completed: 0, total: 24, badge: null as string | null });
  
  const [isAlreadyCompleted, setIsAlreadyCompleted] = useState(false);

  let currentLessonContent: Lesson | null = null;
  let currentModule: Module | null = null; 
  
  for (const module of COURSE_DATA) {
    const foundLesson = module.lessons.find(l => l.id === lesson.id);
    if (foundLesson) {
      currentLessonContent = foundLesson;
      currentModule = module;
      break;
    }
  }

  if (!currentLessonContent || !currentModule) {
    currentLessonContent = COURSE_DATA[0].lessons[0];
    currentModule = COURSE_DATA[0];
  }
  useFocusEffect(
    React.useCallback(() => {
      const checkStatus = async () => {
        try {
          const dataStr = await AsyncStorage.getItem('userData');
          if (dataStr) {
            const data = JSON.parse(dataStr);
            if (data.lessonsCompleted && data.lessonsCompleted.includes(currentLessonContent!.id)) {
              setIsAlreadyCompleted(true);
            }
          }
        } catch (e) {
          console.error(e);
        }
      };
      checkStatus();
    }, [currentLessonContent!.id])
  );

  const markAsCompleted = async () => {
    if (isAlreadyCompleted) return;

    const result = await completeLesson(currentLessonContent!.id, currentModule!);  
    
    if (result && result.data) {
      setIsAlreadyCompleted(true); 
      setSessionStats({
        xp: result.newBadgeEarned ? 150 : 50, 
        completed: result.data.lessonsCompleted.length,
        total: result.data.totalLessons,
        badge: result.newBadgeEarned 
      });
      setShowSuccessModal(true); 
    }
  };

  const handleGoToProfile = () => {
    setShowSuccessModal(false);
    navigation.navigate('Main', { screen: 'Profile' });
  };

  const handleGoBack = () => {
    setShowSuccessModal(false);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.title}>{currentLessonContent.title}</Text>
        
        <View style={styles.tagsContainer}>
          <View style={styles.tag}>
            <MaterialCommunityIcons name="signal-cellular-2" size={14} color={COLORS.primary} />
            <Text style={styles.tagText}>Новачок</Text>
          </View>
          <View style={styles.tag}>
            <MaterialCommunityIcons name="clock-outline" size={14} color={COLORS.textSecondary} />
            <Text style={styles.tagTextSecondary}>{currentLessonContent.duration}</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <MaterialCommunityIcons name="book-open-page-variant" size={24} color={COLORS.primary} />
            <Text style={styles.subtitle}>Теорія</Text>
          </View>
          <Text style={styles.text}>{currentLessonContent.theory}</Text>
        </View>

        <View style={[styles.card, styles.practiceCard]}>
          <View style={styles.cardHeader}>
            <MaterialCommunityIcons name="target" size={24} color={COLORS.accent} />
            <Text style={styles.subtitle}>Практичне завдання</Text>
          </View>
          <Text style={styles.text}>{currentLessonContent.practice}</Text>
          
          <TouchableOpacity 
            style={styles.startPracticeBtn}
            onPress={() => navigation.navigate('Practice', { 
              lessonId: currentLessonContent!.id,
              title: currentLessonContent!.title,
              practiceTask: currentLessonContent!.practiceTask 
            })}
          >
            <Text style={styles.startPracticeText}>Почати практику</Text>
            <MaterialCommunityIcons name="arrow-right" size={18} color={COLORS.primary} />
          </TouchableOpacity>
        </View>

        <View style={styles.actionButtons}>
          <TouchableOpacity 
            style={[styles.completeButton, isAlreadyCompleted && styles.completeButtonDisabled]}
            onPress={markAsCompleted}
            activeOpacity={isAlreadyCompleted ? 1 : 0.8}
          >
            <MaterialCommunityIcons 
              name={isAlreadyCompleted ? "check-all" : "check-decagram"} 
              size={22} 
              color={isAlreadyCompleted ? COLORS.disabledText : "#FFF"} 
              style={{ marginRight: 8 }} 
            />
            <Text style={[styles.primaryButtonText, isAlreadyCompleted && styles.disabledButtonText]}>
              {isAlreadyCompleted ? 'Урок пройдено' : 'Завершити (+50 XP)'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <Modal
        visible={showSuccessModal}
        transparent={true}
        animationType="fade"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalIconContainer}>
              <MaterialCommunityIcons name="trophy" size={50} color={COLORS.accent} />
            </View>
            <Text style={styles.modalTitle}>
              {sessionStats.badge ? 'Модуль завершено!' : 'Чудова робота!'}
            </Text>
            <Text style={styles.modalSubtitle}>
              {sessionStats.badge 
                ? `Ти розблокував досягнення:\n${sessionStats.badge}` 
                : 'Ти успішно завершив цей урок.'}
            </Text>
            <View style={styles.statsContainer}>
              <View style={styles.statBox}>
                <MaterialCommunityIcons name="lightning-bolt" size={24} color={COLORS.accent} />
                <Text style={styles.statValue}>+{sessionStats.xp} XP</Text>
                <Text style={styles.statLabel}>Отримано</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statBox}>
                <MaterialCommunityIcons name="book-check" size={24} color={COLORS.primary} />
                <Text style={styles.statValue}>{sessionStats.completed}/{sessionStats.total}</Text>
                <Text style={styles.statLabel}>Уроків</Text>
              </View>
            </View>
            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.modalBtnPrimary} onPress={handleGoToProfile}>
                <Text style={styles.modalBtnPrimaryText}>До профілю</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.modalBtnSecondary} onPress={handleGoBack}>
                <Text style={styles.modalBtnSecondaryText}>Назад до списку</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  scrollContent: { padding: 20, paddingBottom: 40 },
  
  title: { fontSize: 26, color: COLORS.textMain, fontFamily: 'Manrope_700Bold', marginBottom: 12, lineHeight: 34 },
  tagsContainer: { flexDirection: 'row', marginBottom: 24, gap: 10 },
  tag: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F3E8FF', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, gap: 4 },
  tagText: { fontSize: 13, color: COLORS.primary, fontFamily: 'Manrope_600SemiBold' },
  tagTextSecondary: { fontSize: 13, color: COLORS.textSecondary, fontFamily: 'Manrope_600SemiBold' },

  card: { backgroundColor: COLORS.cardBg, borderRadius: 16, padding: 20, marginBottom: 20, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 8, elevation: 3 },
  practiceCard: { backgroundColor: COLORS.practiceBg, borderColor: '#D8B4FE', borderWidth: 1 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 12, gap: 8 },
  subtitle: { fontSize: 20, color: COLORS.textMain, fontFamily: 'Manrope_700Bold' },
  text: { fontSize: 15, lineHeight: 24, color: COLORS.textMain, fontFamily: 'Manrope_400Regular' },

  startPracticeBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 16, paddingVertical: 10, backgroundColor: '#FFF', borderRadius: 12, gap: 6 },
  startPracticeText: { color: COLORS.primary, fontFamily: 'Manrope_700Bold', fontSize: 15 },

  actionButtons: { gap: 12, marginTop: 10 },
  
  completeButton: { flexDirection: 'row', backgroundColor: COLORS.success, paddingVertical: 16, borderRadius: 16, justifyContent: 'center', alignItems: 'center', shadowColor: COLORS.success, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 4 },
  completeButtonDisabled: {
    backgroundColor: COLORS.disabledBg,
    shadowOpacity: 0,
    elevation: 0,
  },
  primaryButtonText: { color: '#FFF', fontSize: 16, fontFamily: 'Manrope_700Bold' },
  disabledButtonText: { color: COLORS.disabledText },

  modalOverlay: { flex: 1, backgroundColor: COLORS.overlay, justifyContent: 'center', alignItems: 'center', padding: 20 },
  modalContent: { backgroundColor: COLORS.cardBg, width: '100%', borderRadius: 24, padding: 24, alignItems: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 10 }, shadowOpacity: 0.2, shadowRadius: 20, elevation: 10 },
  modalIconContainer: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#FEF3C7', justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 24, color: COLORS.textMain, fontFamily: 'Manrope_700Bold', marginBottom: 8, textAlign: 'center' },
  modalSubtitle: { fontSize: 15, color: COLORS.textSecondary, fontFamily: 'Manrope_400Regular', textAlign: 'center', marginBottom: 24 },
  statsContainer: { flexDirection: 'row', backgroundColor: '#F9FAFB', borderRadius: 16, padding: 16, width: '100%', marginBottom: 24, justifyContent: 'space-around', alignItems: 'center' },
  statBox: { alignItems: 'center', flex: 1 },
  statDivider: { width: 1, height: '80%', backgroundColor: '#E5E7EB' },
  statValue: { fontSize: 18, fontFamily: 'Manrope_700Bold', color: COLORS.textMain, marginTop: 8 },
  statLabel: { fontSize: 12, fontFamily: 'Manrope_600SemiBold', color: COLORS.textSecondary, marginTop: 4 },
  modalButtons: { width: '100%', gap: 12 },
  modalBtnPrimary: { backgroundColor: COLORS.primary, paddingVertical: 16, borderRadius: 16, alignItems: 'center' },
  modalBtnPrimaryText: { color: '#FFF', fontSize: 16, fontFamily: 'Manrope_700Bold' },
  modalBtnSecondary: { backgroundColor: '#F3E8FF', paddingVertical: 16, borderRadius: 16, alignItems: 'center' },
  modalBtnSecondaryText: { color: COLORS.primary, fontSize: 16, fontFamily: 'Manrope_700Bold' },
});


