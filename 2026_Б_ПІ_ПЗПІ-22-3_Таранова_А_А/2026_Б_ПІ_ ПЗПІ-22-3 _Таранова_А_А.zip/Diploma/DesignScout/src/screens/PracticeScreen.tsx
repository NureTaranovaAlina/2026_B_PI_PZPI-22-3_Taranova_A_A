import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert, Image } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { PracticeQuestion } from '../data/courseData';

const COLORS = {
  primary: '#6D28D9',       
  background: '#F9FAFB',    
  cardBg: '#FFFFFF',        
  textMain: '#1F2937',      
  textSecondary: '#6B7280', 
  success: '#10B981',       
  successLight: '#D1FAE5',
  error: '#EF4444',
  errorLight: '#FEE2E2',
  accent: '#F59E0B',        
  border: '#E5E7EB',
};

export default function PracticeScreen({ route }: any) {
  const navigation = useNavigation<any>();
  const { lessonId, title, practiceTask } = route.params;
  
  const task: PracticeQuestion = practiceTask || {
    type: 'choice',
    question: 'Онови завдання у файлі courseData.ts',
    options: ['Ок', 'Добре'],
    correctAnswerIndex: 0, 
    explanation: 'Цей урок ще не має інтерактивного завдання.'
  };

  const [selectedAnswer, setSelectedAnswer] = useState<number | boolean | null>(null);
  const [isChecked, setIsChecked] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  const handleCheck = async () => {
    if (selectedAnswer === null) return;

    let correct = false;
    if (task.type === 'choice') {
      correct = selectedAnswer === task.correctAnswerIndex;
    } else if (task.type === 'boolean') {
      correct = selectedAnswer === task.correctAnswer;
    }

    console.log(`[DEBUG] Вибрано: ${selectedAnswer}, Результат перевірки: ${correct}`);
    setIsCorrect(correct);
    setIsChecked(true);

    if (correct) {
      try {
        const existingData = await AsyncStorage.getItem('userData');
        
        let data = existingData ? JSON.parse(existingData) : { xp: 0 };
        
        if (typeof data.xp !== 'number') {
          data.xp = 0;
        }

        data.xp += 20; 

        await AsyncStorage.setItem('userData', JSON.stringify(data));
        console.log(`[SUCCESS] Успішно збережено! Тепер у тебе: ${data.xp} XP`);
        
      } catch (e) {
        console.error("[ERROR] Помилка збереження XP:", e);
      }
    }
  };

  const handleContinue = () => {
    if (isCorrect) {
      navigation.goBack(); 
    } else {
      setIsChecked(false);
      setSelectedAnswer(null);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <MaterialCommunityIcons name="close" size={28} color={COLORS.textSecondary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Практика</Text>
        <View style={{ width: 28 }} /> 
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <Text style={styles.lessonTitle}>{title}</Text>
        
        <Text style={styles.questionText}>{task.question}</Text>

        {task.imageUri && (
            <View style={styles.imageContainer}>
            <Image source={{ uri: task.imageUri }} style={styles.taskImage} resizeMode="contain" />
            </View>
        )}

        <View style={styles.optionsContainer}>
          
          {task.type === 'choice' && task.options && task.options.map((option, index) => {
            const isSelected = selectedAnswer === index; 
            const showCorrect = isChecked && index === task.correctAnswerIndex;
            const showWrong = isChecked && isSelected && !isCorrect;

            return (
              <TouchableOpacity 
                key={index}
                style={[
                  styles.optionBtn,
                  isSelected && styles.optionSelected,
                  showCorrect && styles.optionCorrect,
                  showWrong && styles.optionWrong
                ]}
                onPress={() => !isChecked && setSelectedAnswer(index)} 
                disabled={isChecked}
              >
                <Text style={[
                  styles.optionText,
                  (isSelected || showCorrect) && styles.optionTextActive
                ]}>
                  {option}
                </Text>
                
                {showCorrect && <MaterialCommunityIcons name="check-circle" size={24} color={COLORS.success} />}
                {showWrong && <MaterialCommunityIcons name="close-circle" size={24} color={COLORS.error} />}
              </TouchableOpacity>
            );
          })}

          {task.type === 'boolean' && (
            <View style={styles.booleanContainer}>
              {[true, false].map((val) => {
                const isSelected = selectedAnswer === val;
                const showCorrect = isChecked && val === task.correctAnswer;
                const showWrong = isChecked && isSelected && !isCorrect;
                
                return (
                  <TouchableOpacity 
                    key={val ? 'true' : 'false'}
                    style={[
                      styles.optionBtn,
                      isSelected && styles.optionSelected,
                      showCorrect && styles.optionCorrect,
                      showWrong && styles.optionWrong
                    ]}
                    onPress={() => !isChecked && setSelectedAnswer(val)}
                    disabled={isChecked}
                  >
                    <Text style={[
                      styles.optionText,
                      (isSelected || showCorrect) && styles.optionTextActive
                    ]}>
                      {val ? 'Так, це правда' : 'Ні, це хибно'}
                    </Text>
                    {showCorrect && <MaterialCommunityIcons name="check-circle" size={24} color={COLORS.success} />}
                    {showWrong && <MaterialCommunityIcons name="close-circle" size={24} color={COLORS.error} />}
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </View>

      </ScrollView>

      <View style={styles.bottomFooter}>
        {isChecked ? (
          <View style={[styles.resultPanel, isCorrect ? styles.resultCorrect : styles.resultWrong]}>
            <View style={styles.resultHeader}>
              <MaterialCommunityIcons 
                name={isCorrect ? "check-decagram" : "alert-circle"} 
                size={28} 
                color={isCorrect ? COLORS.success : COLORS.error} 
              />
              <Text style={[styles.resultTitle, { color: isCorrect ? COLORS.success : COLORS.error }]}>
                {isCorrect ? 'Чудово! (+20 XP)' : 'Не зовсім так'}
              </Text>
            </View>
            <Text style={styles.explanationText}>{task.explanation}</Text>
            
            <TouchableOpacity 
              style={[styles.checkBtn, { backgroundColor: isCorrect ? COLORS.success : COLORS.error }]} 
              onPress={handleContinue}
            >
              <Text style={styles.checkBtnText}>{isCorrect ? 'Продовжити' : 'Спробувати ще раз'}</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.checkPanel}>
            <TouchableOpacity 
              style={[styles.checkBtn, selectedAnswer === null && styles.checkBtnDisabled]} 
              onPress={handleCheck}
              disabled={selectedAnswer === null}
            >
              <Text style={styles.checkBtnText}>Перевірити</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingTop: 60, paddingHorizontal: 20, paddingBottom: 16, backgroundColor: COLORS.background,
  },
  backBtn: { padding: 4 },
  headerTitle: { fontSize: 18, fontFamily: 'Manrope_700Bold', color: COLORS.textMain },
  scrollContent: { padding: 24, paddingBottom: 120 },
  
  lessonTitle: { fontSize: 14, fontFamily: 'Manrope_600SemiBold', color: COLORS.textSecondary, marginBottom: 12, textTransform: 'uppercase' },
  questionText: { fontSize: 24, fontFamily: 'Manrope_700Bold', color: COLORS.textMain, lineHeight: 34, marginBottom: 24 },
  
  imageContainer: {
    width: '100%', height: 200, backgroundColor: COLORS.cardBg, borderRadius: 16,
    marginBottom: 24, borderWidth: 1, borderColor: COLORS.border, overflow: 'hidden'
  },
  taskImage: { width: '100%', height: '100%' },

  optionsContainer: { gap: 12 },
  booleanContainer: { gap: 12 },

  optionBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: COLORS.cardBg, padding: 20, borderRadius: 16,
    borderWidth: 2, borderColor: COLORS.border,
  },
  optionSelected: { borderColor: COLORS.primary, backgroundColor: '#F3E8FF' },
  optionCorrect: { borderColor: COLORS.success, backgroundColor: COLORS.successLight },
  optionWrong: { borderColor: COLORS.error, backgroundColor: COLORS.errorLight },
  
  optionText: { fontSize: 16, fontFamily: 'Manrope_600SemiBold', color: COLORS.textMain, flex: 1, paddingRight: 10 },
  optionTextActive: { color: COLORS.textMain },

  bottomFooter: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: COLORS.cardBg,
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    shadowColor: '#000', shadowOffset: { width: 0, height: -4 }, shadowOpacity: 0.1, shadowRadius: 10, elevation: 15,
  },
  checkPanel: { padding: 24, paddingBottom: 40 },
  checkBtn: { backgroundColor: COLORS.primary, paddingVertical: 18, borderRadius: 16, alignItems: 'center' },
  checkBtnDisabled: { backgroundColor: '#E5E7EB' },
  checkBtnText: { color: '#FFF', fontSize: 18, fontFamily: 'Manrope_700Bold' },

  resultPanel: { padding: 24, paddingBottom: 40 },
  resultCorrect: { backgroundColor: COLORS.successLight },
  resultWrong: { backgroundColor: COLORS.errorLight },
  resultHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 12, gap: 8 },
  resultTitle: { fontSize: 20, fontFamily: 'Manrope_700Bold' },
  explanationText: { fontSize: 15, fontFamily: 'Manrope_400Regular', color: COLORS.textMain, marginBottom: 20, lineHeight: 22 },
});
