import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

const COLORS = {
  primary: '#6D28D9',
  background: '#F9FAFB',
  cardBg: '#FFFFFF',
  textMain: '#1F2937',
  textSecondary: '#6B7280',
  danger: '#EF4444',
  dangerBg: '#FEF2F2',
  dangerBorder: '#FECACA',
};

export default function SettingsScreen() {
  const navigation = useNavigation<any>();

  const resetProgress = () => {
    Alert.alert(
      'Скинути прогрес?',
      'Це видалить твоє ім\'я, XP та всі пройдені уроки. Дія незворотна!',
      [
        { text: 'Скасувати', style: 'cancel' },
        {
          text: 'Скинути',
          style: 'destructive',
          onPress: async () => {
            await AsyncStorage.clear();
            // Скидаємо навігацію на екран привітання
            navigation.reset({
              index: 0,
              routes: [{ name: 'Welcome' }],
            });
          }
        }
      ]
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Налаштування</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.sectionTitle}>Дані додатку</Text>
        <View style={styles.card}>
          <TouchableOpacity style={styles.dangerButton} onPress={resetProgress}>
            <View style={styles.dangerIconContainer}>
              <MaterialCommunityIcons name="trash-can-outline" size={24} color={COLORS.danger} />
            </View>
            <View style={styles.dangerTextContainer}>
              <Text style={styles.dangerTitle}>Скинути весь прогрес</Text>
              <Text style={styles.dangerSubtitle}>Видалення всіх досягнень та XP</Text>
            </View>
            <MaterialCommunityIcons name="chevron-right" size={24} color={COLORS.textSecondary} />
          </TouchableOpacity>
        </View>
        <Text style={styles.sectionTitle}>Про додаток</Text>
        <View style={styles.card}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Версія</Text>
            <Text style={styles.infoValue}>1.0.0</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Розробник</Text>
            <Text style={styles.infoValue}>Таранова Аліна</Text>
          </View>
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
    backgroundColor: COLORS.cardBg,
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 24,
    color: COLORS.textMain,
    fontFamily: 'Manrope_700Bold',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 100, 
  },
  sectionTitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontFamily: 'Manrope_600SemiBold',
    textTransform: 'uppercase',
    marginBottom: 8,
    marginLeft: 4,
    marginTop: 16,
  },
  card: {
    backgroundColor: COLORS.cardBg,
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  dangerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: COLORS.dangerBg,
  },
  dangerIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FEE2E2',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  dangerTextContainer: {
    flex: 1,
  },
  dangerTitle: {
    fontSize: 16,
    color: COLORS.danger,
    fontFamily: 'Manrope_600SemiBold',
  },
  dangerSubtitle: {
    fontSize: 13,
    color: COLORS.danger,
    opacity: 0.8,
    fontFamily: 'Manrope_400Regular',
    marginTop: 2,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  infoLabel: {
    fontSize: 16,
    color: COLORS.textMain,
    fontFamily: 'Manrope_400Regular',
  },
  infoValue: {
    fontSize: 16,
    color: COLORS.textSecondary,
    fontFamily: 'Manrope_600SemiBold',
  },
  divider: {
    height: 1,
    backgroundColor: '#E5E7EB',
    marginLeft: 16,
  },
});
