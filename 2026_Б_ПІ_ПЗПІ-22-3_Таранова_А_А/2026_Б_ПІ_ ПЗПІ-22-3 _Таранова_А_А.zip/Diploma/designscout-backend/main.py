from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from PIL import Image
import io
import base64
import random
from datetime import datetime
from typing import List, Dict

app = FastAPI(title="DesignScout AI Analyzer")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UX_RULES = {
    "contrast": {
        "message": "Недостатній контраст тексту/кнопок (WCAG 4.5:1)",
        "severity": "high" if random.random() < 0.4 else "medium"
    },
    "spacing": {
        "message": "Недостатні відступи між елементами (8pt grid)",
        "severity": "medium"
    },
    "typography": {
        "message": "Невідповідність розміру шрифту (hierarchy)",
        "severity": "low"
    },
    "alignment": {
        "message": "Елементи не вирівняні по сітці",
        "severity": "medium"
    },
    "touch_target": {
        "message": "Кнопки замалі (min 44x44pt)",
        "severity": "high"
    }
}

def generate_realistic_issues(image_width: int, image_height: int) -> List[Dict]:
    issues = []
    
    num_issues = random.randint(1, 4)
    issue_types = random.sample(list(UX_RULES.keys()), num_issues)
    
    for i, issue_type in enumerate(issue_types):
        rule = UX_RULES[issue_type]
        
        x = random.randint(20, image_width - 200)
        y = random.randint(50, image_height - 100)
        width = random.randint(80, 250)
        height = random.randint(30, 80)
        
        issues.append({
            "id": i + 1,
            "type": issue_type,
            "severity": rule["severity"],
            "message": rule["message"],
            "x": x,
            "y": y,
            "width": width,
            "height": height,
            "fix": f"Виправити {issue_type}: {random.choice(['Збільшити контраст', 'Додати padding', 'Змінити font-size', 'Вирівняти по baseline'])}"
        })
    
    return issues

@app.post("/analyze")
async def analyze_interface(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents))
        width, height = image.size
        
        print(f"Отримано зображення: {width}x{height}")
        
        issues = generate_realistic_issues(width, height)
        
        severity_weights = {"high": 30, "medium": 15, "low": 5}
        penalty = sum(severity_weights.get(issue["severity"], 0) for issue in issues)
        score = max(60, 100 - penalty)
        
        result = {
            "success": True,
            "timestamp": datetime.now().isoformat(),
            "image_width": width,
            "image_height": height,
            "issues": issues,
            "score": round(score, 1),
            "total_issues": len(issues),
            "recommendations": [
                "Перевірте Accessibility guidelines",
                "Використовуйте 8pt grid system",
                "Тестуйте на реальних пристроях"
            ]
        }
        
        print(f"✅ Аналіз завершено: {score}% ({len(issues)} проблем)")
        return result
        
    except Exception as e:
        print(f"❌ Помилка: {str(e)}")
        raise HTTPException(status_code=500, detail="Помилка обробки зображення")

@app.get("/")
async def root():
    return {"message": "DesignScout AI Analyzer запущено!", "endpoint": "/analyze"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
